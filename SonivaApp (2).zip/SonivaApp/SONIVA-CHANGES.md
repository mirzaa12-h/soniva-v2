# Soniva — perubahan dari Rythim Music 13.5.0

Soniva adalah turunan dari Rythim Music (GPL-3.0), yang diturunkan dari Metrolist dan InnerTune.
Kredit dan lisensi asli tetap dipertahankan (lihat LICENSE dan README.md).

## Perubahan
- ID aplikasi `com.soniva.app` dan nama aplikasi "Soniva" (app/build.gradle.kts); shortcut menyesuaikan.
- Updater bawaan dimatikan di flavor foss agar tidak mengarah ke rilis Rythim.
- Bar navigasi liquid glass: blur konten halaman di belakang bar, tint tema, kilau tepi atas
  (ui/utils/GlassEffects.kt, ui/component/AppNavigation.kt, MainActivity.kt).
- Lirik frosted glass: panel kaca pada tampilan lirik di pemutar (ui/player/Player.kt, InlineLyricsView).
- MiniPlayer mengecil saat halaman di-scroll dan kembali normal saat scroll ke atas
  (ui/utils/GlassEffects.kt, ui/player/MiniPlayer.kt, MainActivity.kt).
- Judul beranda diganti menjadi "Soniva".
