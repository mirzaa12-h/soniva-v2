/**
 * Soniva additions (GPL-3.0, derived from Rythim Music / Metrolist / InnerTune)
 * Efek kaca: backdrop blur untuk bar navigasi, panel frosted untuk lirik,
 * dan state penyusutan MiniPlayer saat scroll.
 */

package com.rythim.music.ui.utils

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ---------------------------------------------------------------------------
// Panel frosted glass (dipakai untuk lirik)
// ---------------------------------------------------------------------------

/**
 * Panel kaca buram: gradasi tint tipis + garis tepi yang memantulkan cahaya.
 * Latar di belakang panel (mis. sampul album yang sudah di-blur) tetap terlihat samar.
 */
@Composable
fun Modifier.frostedGlass(shape: Shape = RoundedCornerShape(28.dp)): Modifier {
    val base = MaterialTheme.colorScheme.onSurface
    return this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(base.copy(alpha = 0.14f), base.copy(alpha = 0.05f)),
            ),
        ).border(
            width = 1.dp,
            brush = Brush.verticalGradient(
                listOf(base.copy(alpha = 0.35f), base.copy(alpha = 0.06f)),
            ),
            shape = shape,
        )
}

// ---------------------------------------------------------------------------
// Backdrop blur (dipakai untuk bar navigasi liquid glass)
// ---------------------------------------------------------------------------

/** Menyimpan rekaman konten halaman yang akan di-blur di belakang bar. */
@Stable
class GlassBackdropState internal constructor(
    internal val layer: GraphicsLayer,
) {
    internal var sourceOrigin by mutableStateOf(Offset.Zero)

    // Dinaikkan setiap kali konten sumber digambar ulang, supaya bar ikut menggambar ulang
    internal val version = mutableIntStateOf(0)
    private var ticks = 0

    internal fun bump() {
        version.intValue = ++ticks
    }
}

@Composable
fun rememberGlassBackdropState(): GlassBackdropState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassBackdropState(layer) }
}

/** Pasang pada konten halaman (di belakang bar). */
fun Modifier.glassBackdropSource(state: GlassBackdropState): Modifier =
    this
        .onGloballyPositioned { state.sourceOrigin = it.positionInWindow() }
        .drawWithContent {
            state.layer.record {
                this@drawWithContent.drawContent()
            }
            drawLayer(state.layer)
            state.bump()
        }

/**
 * Pasang pada bar. Menggambar salinan konten halaman yang di-blur (Android 12+),
 * lalu tint tema dan kilau tipis di tepi atas.
 */
@Composable
fun Modifier.glassBackdrop(
    state: GlassBackdropState,
    shape: Shape,
    baseColor: Color,
    tint: Color,
    highlight: Color,
    blurRadius: Dp = 28.dp,
): Modifier {
    val blurLayer = rememberGraphicsLayer()
    var origin by remember { mutableStateOf(Offset.Zero) }
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    return this
        .clip(shape)
        .onGloballyPositioned { origin = it.positionInWindow() }
        .drawBehind {
            // Dasar buram agar konten tajam di belakang bar tidak tembus
            drawRect(baseColor)
            if (canBlur) {
                state.version.intValue // berlangganan: gambar ulang saat konten sumber berubah
                val radius = blurRadius.toPx()
                blurLayer.renderEffect = BlurEffect(radius, radius, TileMode.Clamp)
                blurLayer.record {
                    val delta = state.sourceOrigin - origin
                    translate(delta.x, delta.y) {
                        drawLayer(state.layer)
                    }
                }
                drawLayer(blurLayer)
            }
            drawRect(tint)
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(highlight, Color.Transparent),
                    startY = 0f,
                    endY = size.height,
                ),
            )
        }
}

// ---------------------------------------------------------------------------
// MiniPlayer mengecil saat scroll
// ---------------------------------------------------------------------------

/**
 * fraction: 0f = ukuran normal, 1f = paling kecil.
 * Scroll ke bawah (isi bergerak naik) mengecilkan, scroll ke atas mengembalikan.
 */
@Stable
class MiniPlayerShrinkState(
    private val distancePx: Float = 320f,
) {
    var fraction by mutableFloatStateOf(0f)
        private set

    val connection =
        object : NestedScrollConnection {
            override fun onPreScroll(
                available: Offset,
                source: NestedScrollSource,
            ): Offset {
                if (available.y != 0f) {
                    fraction = (fraction - available.y / distancePx).coerceIn(0f, 1f)
                }
                return Offset.Zero
            }
        }
}

val LocalMiniPlayerShrink = staticCompositionLocalOf { MiniPlayerShrinkState() }
